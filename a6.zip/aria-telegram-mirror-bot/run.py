from os import system


system("apt install aria2")
system("npm install -g typescript")
system("npm install")
system("tsc")
system("bash start.sh")
system("npm start")